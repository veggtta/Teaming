<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 用户发布消息，将要发布的消息录入到数据库中
 */

$openid = $_POST['openid'];  //用户id
$title = $_POST['title'];  //标题
$post_time = $_POST['post_time'];  //发布时间
$com_id = $_POST['com_id'];   //赛事id
$num_people = $_POST['num_people'];  //目前人数
$aim_college = $_POST['aim_college'];  //意向学院id
$detail = $_POST['detail'];  //需求详情
$stage = $_POST['stage'];  //进展

$conn = mysql_connect::get_SQL_connect();
$sql = "call posting('$openid', '$title', '$post_time', $com_id, $num_people, $aim_college, '$detail', '$stage')";
$result = $conn->query($sql);

if($result){
    echo_encode_json(0, '发布成功');
}else{
    echo_encode_json(1, "发布失败");
}

$conn->close();