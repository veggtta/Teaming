<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 通过比赛名字模糊查询比赛 <br>
 * 将读取到的各比赛名称存放在一个数组中，<br>
 * [{id: 比赛编号, name: 比赛名字, logo: 图标地址},...]<br>
 * 再将数组转换成json格式返回。
 * @param $competition '比赛名'
 */
function queryCompetitionByName($competition){

    $competition = "%".$competition;
    $competition = $competition."%";
    $conn = mysql_connect::get_SQL_connect();
    $sql = "select * from competition where com_name like '$competition';";
//    $sql = "select * from competition where com_name like '%大学%';";
    $result = $conn->query($sql);

    if($result->num_rows > 0){

        $competition_array = array();
        while ($row = $result->fetch_assoc()){
            //array_push($college_array, $row);
            $competition = array(
                "id" => $row["com_id"],
                "name" => $row["com_name"],
                "logo" => $row["com_logo"]
            );
            $competition_array[] = $competition;
        }
        echo_encode_json(0, $competition_array);

    }else{
        echo_encode_json(1, "查询比赛表失败/没有此类比赛");   //查询比赛表失败
    }

    $conn->close();
}



$competition = $_GET["competition_name"];
//echo $college;
queryCompetitionByName($competition);