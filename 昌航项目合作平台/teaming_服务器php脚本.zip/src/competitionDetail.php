<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 *
 */
function getCompetitionDetail($id){

    #$college_name = $college;
    $conn = mysql_connect::get_SQL_connect();
//    $sql = "call get_one_college_competition('$college');";
    $sql = "select *
        from competition
        where com_id = $id;";
    #$result = $conn->prepare($sql);
    $result = $conn->query($sql);

    if($result->num_rows > 0){

        //$competition_array = array();
        while ($row = $result->fetch_assoc()){
            //array_push($college_array, $row);
            $competition = array(
                "id" => $row["com_id"],
                "name" => $row["com_name"],
                "logo" => $row["com_logo"],
                "level" => $row["level"],
                "content" => $row["com_introduction"]
            );
            //$competition_array[] = $competition;
        }
        echo_encode_json(0, $competition);

    }else{
        echo_encode_json(1, "查询比赛详情表失败");   //查询比赛表失败
    }

    $conn->close();
}



$id = $_GET["id"];
//echo $college;
getCompetitionDetail($id);