<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 通过发布者的id查看发布者的详细信息<br>
 * @param $publisher_id '发布者的id'
 */
function look_publisher_detail($publisher_id){

    $conn = mysql_connect::get_SQL_connect();
    if($conn){

        $sql = "select user_name,avatar, sex, grade, college_name, experience, qq, weixin, tel, user_introduction 
                from user, college 
                where user_id = '$publisher_id' and user.college_id = college.college_id;";
        $result = $conn->query($sql);

        if(!$result){
            echo_encode_json(2, '查询失败');

        }else{
            if($result->num_rows > 0){
                echo_encode_json(0, $result->fetch_assoc());
            }else{
                echo_encode_json(3, '没有此用户');
            }
        }

    }else{
        echo_encode_json(1, '数据库连接失败');
    }

    $conn->close();

}



$publisher_id = $_GET['publisher_id'];

look_publisher_detail($publisher_id);


