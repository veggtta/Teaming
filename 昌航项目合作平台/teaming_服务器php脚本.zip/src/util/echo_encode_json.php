<?php


/**
 * 将传入的状态码和数据储存在一个关联数组中，
 * 再将这个数组转换成json文件输出。
 * @param $code 状态码
 * @param $date 数据
 */
function echo_encode_json($code, $date){
    $arr = array(
        "code" => $code,
        "data" => $date
    );
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
}
