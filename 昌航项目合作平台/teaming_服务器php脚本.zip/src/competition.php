<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 通过学院名字获取某学院的比赛 <br>
 * 将读取到的各比赛名称存放在一个数组中，<br>
 * [{id: 比赛编号, name: 比赛名字, logo: 图标地址},...]<br>
 * 再将数组转换成json格式返回。
 * @param $college '学院名，查询此学院的比赛'
 */
function getCompetition($college){

    #$college_name = $college;
    $conn = mysql_connect::get_SQL_connect();
    $sql = "call get_one_college_competition('$college');";
//    $sql = "select distinct competition.com_id,competition.com_name
//        from competition,college,com_college
//        where college_name = '$college' and
//              com_college.college_id = college.college_id and
//              competition.com_id = com_college.com_id;";
    #$result = $conn->prepare($sql);
    $result = $conn->query($sql);

    if($result->num_rows > 0){

        $competition_array = array();
        while ($row = $result->fetch_assoc()){
            //array_push($college_array, $row);
            $competition = array(
                "id" => $row["com_id"],
                "name" => $row["com_name"],
                "logo" => $row["com_logo"]
            );
            $competition_array[] = $competition;
        }
        echo_encode_json(0, $competition_array);

    }else{
        echo_encode_json(1, "查询比赛表失败");   //查询比赛表失败
    }

    $conn->close();
}



$college = $_GET["college"];
//echo $college;
getCompetition($college);