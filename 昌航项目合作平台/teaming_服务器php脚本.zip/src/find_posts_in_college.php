<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 分页查询发表的帖子（未过期的，用于显示在学院页面），每页数量10<br>
 * @param $page '第几页'
 * @param $college_id '学院id'
 * @param $is_this_college '本学院或者意向本学院'
 */
function find_posts_in_college($page, $college_id, $is_this_college){

    $conn = mysql_connect::get_SQL_connect();
    $sql = null;
    if($is_this_college == "true"){
        $sql = "call select_in_college($page, $college_id);";
    }else{
        $sql = "call select_in_aim_college($page, $college_id);";
    }

    if($conn){
        $result = $conn->query($sql);

        if(!$result){
            echo_encode_json(2, '查询失败');

        }else{
            if($result->num_rows > 0){
                $post_list = array();
                while ($row = $result->fetch_assoc()){
                    $post_list[] = $row;
                }
                echo_encode_json(0, $post_list);
            }else{
                echo_encode_json(3, '没有更多信息了');
            }
        }

    }else{
        echo_encode_json(1, '数据库连接失败');
    }

    $conn->close();

}



$page = $_GET['page'];
$college_id = $_GET['college_id'];
$is_this_college = $_GET['is_this_college'];

find_posts_in_college($page, $college_id,$is_this_college);


