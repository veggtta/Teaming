<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 获取学院数据 <br>
 * 将读取到的各学院名称存放在一个对象数组中，<br>
 * [{id: 学院编号, name: 学院名字, logo: 图标地址},...]<br>
 * 再将数组转换成json格式返回。
 */
function getCollege(){

    $conn = mysql_connect::get_SQL_connect();
    $sql = "select college_id,college_name,college_logo from college;";
    $result = $conn->query($sql);

    if($result->num_rows > 0){

        $college_array = array();
        while ($row = $result->fetch_assoc()){
            //array_push($college_array, $row);
            $college = array(
                "id" => $row["college_id"],
                "name" => $row["college_name"],
                "logo" => $row['college_logo']
            );
            $college_array[] = $college;
        }
        echo_encode_json(0, $college_array);

    }else{
        echo_encode_json(1, '查询学院表失败');
    }

    $conn->close();

}

getCollege();