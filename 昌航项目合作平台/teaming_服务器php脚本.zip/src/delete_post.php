<?php

require "util/mysql_connect.php";
require "util/echo_encode_json.php";

/**
 * 删除帖子<br>
 * @param $news_id '帖子id'
 */
function delete($news_id){

    $conn = mysql_connect::get_SQL_connect();
    if($conn){

        $sql = "delete from news where news_id = $news_id;";
        $result = $conn->query($sql);

        if($result){
            echo_encode_json(0, '删除成功');
        }else{
            echo_encode_json(2, "删除失败");
        }

    }else{
        echo_encode_json(1, '数据库连接失败');
    }

    $conn->close();

}



$news_id = $_GET['news_id'];

delete($news_id);



